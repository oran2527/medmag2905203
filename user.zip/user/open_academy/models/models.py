# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.modules.module import get_module_resource
from odoo.exceptions import ValidationError

from io import BytesIO
from xlrd import open_workbook
import base64
import datetime
import json
import os
import tempfile

class open_academy(models.Model):
    _name = 'open_academy.open_academy'
    _description = 'open_academy.open_academy'

    name = fields.Char(string="Nombre")
    anio = fields.Integer(string="Año")
    concepto = fields.Char(string="Concepto")
    formato = fields.Char(string="Formato")
    xls = fields.Binary(string='Archivo', attachment=True, help='Upload the excel file', required=True)
    txt_path = fields.Char(string='Ruta Archivo Texto')
    txt_data = fields.Char(string='Lista Registros')
    """
    @api.depends('value')
    def _value_pc(self):
        for record in self:
            record.value2 = float(record.value) / 100
    """

    #actualiza la informacion del nuevo medio magnetico en la vista principal
    def descargar_archivo_txt(self):
        #traemos la informacion del archivo generado txt en odoo en funcion trans
        base_url, download_url = self.trans()
        
        #retorno al usuario
        return {
            "type": "ir.actions.act_url",
            "url": str(base_url) + str(download_url),
            "target": "new",
        }

    def validar_excel_guardar(self):
        self.trans()
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }

    # metodo para el boton transformar de la vista listado.
    # obtiene el resultado de procesar el excel con las reglas 

    def trans(self):

        #arreglo total que contendra texto por cada final del excel
        txt_data = []

        # ruta para acceder archivo de reglas
        rule_path_json = get_module_resource('open_academy', 'rules', 'reglas.json')        
        
        # extrae informacion del archivo json con las reglas
        with open(rule_path_json) as reglas:
            datos_reglas = json.load(reglas)

        # extraccion en variables de las regla anio
        anio_json_type = datos_reglas[0]['tipo']
        anio_json_size = int(datos_reglas[0]['TAMANO'])

        # extraccion en variables de las regla concepto
        concepto_json_type = datos_reglas[1]['tipo']
        concepto_json_size = int(datos_reglas[1]['TAMANO'])

        # extraccion en variables de las regla valor
        valor_json_type = datos_reglas[2]['tipo']
        valor_json_size = int(datos_reglas[2]['TAMANO'])
        

        for record in self:
            
            # pasos para decodificar archivo de bytes del campo xls        
            inputx = BytesIO()
            inputx.write(base64.decodestring(self.xls))
            book = open_workbook(file_contents=inputx.getvalue())
            
            #acceder a la hoja inicial del archivo de excel
            sh = book.sheet_by_index(0)
            
            #variable cont para evitar la primera fila que son los titulos en bucle for
            cont = True

            #ingresa fila por fila para verificar cada valor de las celdas anio, concepto y valor
            for rx in range(sh.nrows):
                
                if cont == True:
                    titulo1 = sh.row(rx)[0].value
                    titulo2 = sh.row(rx)[1].value
                    if titulo1.upper() == 'NIT' and titulo2.upper() == 'VALOR':
                        cont = False
                        continue
                    else:
                        # condicion para verificar que el archivo de excel tenga titulos nit y valor en la primera fila
                        cont = False
                        raise ValidationError("El archivo de excel debe tener titulos 'nit' y 'valor' en ese orden en la primera fila")

                anio_txt = ''
                concepto_txt = ''
                valor_txt = ''

                #anio_txt = validations_anio_valor(sh.row(rx)[0].value, anio_json_type, anio_json_size)
                anio_txt = validations_anio_valor(self.anio, anio_json_type, anio_json_size)
                #concepto_txt = validations_concepto(sh.row(rx)[1].value, concepto_json_type, concepto_json_size)
                concepto_txt = validations_concepto(self.concepto, concepto_json_type, concepto_json_size)
                valor_txt = validations_anio_valor(sh.row(rx)[1].value, valor_json_type, valor_json_size)
                               

                txt_data.append(anio_txt + concepto_txt + valor_txt)
        
        

        # ruta para acceder archivo de texto
        
        current_date = datetime.datetime.now()
        cyear = str(current_date.year) + "_"
        cmonth = str(current_date.month) + "_"
        cday = str(current_date.day) + "_"
        chour = str(current_date.hour) + "_"
        cmin = str(current_date.minute) + "_"
        csec = str(current_date.second) 
        filename = "archivo_final_" + cyear + cmonth + cday + chour + cmin + csec + ".txt"  
        #txt_path = new_path + "/../server/odoo/addons/user/open_academy/static/" + filename
        txt_path = get_module_resource('open_academy', 'static') + '\\' + str(filename)
        
        # se abre archivo txt para escribir la informacion del array
        with open(txt_path, 'wt') as final_text:
            for n in txt_data:
                final_text.write(n + '\n')

        
        
        #leer el archivo de texto para descargar directamente

        #lee el archivo txt 
        output = open(txt_path, "r")

        #base_url consigue la url que usa la aplicacion
        base_url = self.env['ir.config_parameter'].get_param('web.base.url')

        #convierte el archivo en archivo binario 
        result = base64.b64encode((output.read()).encode())
        attachment_obj = self.env['ir.attachment']
        attach_name = '_año_' + str(self.anio) + '_concepto_' + str(self.concepto) + '_fecha_' + cyear + cmonth + cday + '_hora_' + chour + '_minuto_' + cmin + '_segundo_' + csec + ".txt"
        
        #crea el objeto a adjuntar o descargar
        attachment_id = attachment_obj.create(
	        {'name': attach_name, 'datas': result})
        
        #ruta de descarga que maneja odoo
        download_url = '/web/content/' + str(attachment_id.id) + '?download=true'
        
        #retorna base_url y download_url para poder hacer descarga en
        #funcion descargar_archivo_txt
        return base_url, download_url
    
    
        

#funcion para validar las variables anio y valor
def validations_anio_valor(value, json_type, json_size):
    if not type(value) == str:
        value = int(value)
    if(str(value) == 'NaN' or str(value) == 'None'):
        return ''        
    elif(len(str(value)) < json_size):
        return ('0' * (json_size - len(str(value))) + str(value))
    else:
        return str(value)

#funcion para validar reglas del campo concepto
def validations_concepto(value, json_type, json_size):
    if not type(value) == str:
        value = int(value)
    if(str(value) == 'NaN' or str(value) == 'None'):
        return ''        
    elif(len(str(value)) < json_size):
        return (str(value) + '$' * (json_size - len(str(value))))
    else:
        return str(value)
    

